package org.application.spring_boot_application.util.constants;

public enum jwtkeys {
    JWT_KEY("tuFNgRgu6mcl0xtwbClgoNCYGW/iPalvd4NovOe8OQU=");

    private final String jwtKeyString;

    private jwtkeys(String jwtKeyString) {
        this.jwtKeyString = jwtKeyString;
    }

    public String getJwtKeyString() {
        return this.jwtKeyString;
    }
}

