package org.application.spring_boot_application.Repositories;

import java.util.Optional;

import org.application.spring_boot_application.Entities.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long>{
    Optional<User> findByUserId(Long user_id);
    Optional<User> findByUsernameString(String usernameString);
    Optional<User> findByEmailString(String emailString);
    void deleteByUserId(Long id);
}
