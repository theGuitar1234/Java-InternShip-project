package org.application.spring_boot_application.SeedData;

import org.application.spring_boot_application.Entities.Movie;
import org.application.spring_boot_application.Entities.User;
import org.application.spring_boot_application.Services.MovieService;
import org.application.spring_boot_application.Services.UserService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class SeedData implements CommandLineRunner {

    private final MovieService movieService;

    private final UserService userService;

    private final PasswordEncoder passwordEncoder;

    public SeedData(MovieService movieService, UserService userService, PasswordEncoder passwordEncoder) {
        this.movieService = movieService;
        this.passwordEncoder = passwordEncoder;
        this.userService = userService;
    }

    @Override
    public void run(String... args) throws Exception {
        Movie movie = new Movie();
        movie.setMovieTitleString("The GodFather");
        movie.setMovieDirectorString("Jon Smith");
        movie.setReleaseYear(1972);
        movie.setGenreString("Drama");
        movie.setIMDbRating(9.2);

        Movie movie2 = new Movie();
        movie2.setMovieTitleString("Rashawnk Redemption");
        movie2.setMovieDirectorString("Craig Mazin");
        movie2.setReleaseYear(2005);
        movie2.setGenreString("Drama");
        movie2.setIMDbRating(9.3);

        User user = new User();
        user.setUsernameString("Thomas1234");
        user.setEmailString("thomas1234@gmail.com");
        user.setPasswordString(passwordEncoder.encode("1234"));
        user.setExperienceString("Has Some Experiences");
        user.setEducationString("Bachelor");

        movieService.save(movie);
        movieService.save(movie2);

        userService.save(user);
        userService.loadUserByUsername(user.getUsernameString());
    }
    
}
