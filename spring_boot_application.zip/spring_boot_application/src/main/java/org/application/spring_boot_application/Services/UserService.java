package org.application.spring_boot_application.Services;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.application.spring_boot_application.Entities.User;
import org.application.spring_boot_application.Repositories.UserRepository;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import org.springframework.transaction.annotation.Transactional;

import jakarta.validation.Valid;

@Service
public class UserService implements UserDetailsService {
    
    private final UserRepository userRepository;

    private final PasswordEncoder passwordEncoder;

    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Optional<User> userOptional = userRepository.findByUsernameString(username);

        User user = userOptional.orElseThrow(() -> new RuntimeException());

        List<GrantedAuthority> grantedAuthorities = new ArrayList<>();

        UserDetails userDetails = org.springframework.security.core.userdetails.User.withUsername(user.getUsernameString())
                                                                                        .password(user.getPasswordString())
                                                                                        .authorities(grantedAuthorities)
                                                                                        .build();
        return userDetails;
    }

    public User save(@Valid User user) {
        if (user.getCreatedAt() == null) {
            user.setCreatedAt(LocalDateTime.now());
        }
        User savedUser = userRepository.save(user);
        return savedUser;
    }

    public User getUserById(Long id) {
        Optional<User> userOptional = userRepository.findByUserId(id);
        User user = userOptional.orElseThrow(() -> new RuntimeException("User not Found"));
        return user;
    }

    public User getUserByUsernameString(String username) {
        Optional<User> userOptional = userRepository.findByUsernameString(username);
        User user = userOptional.orElseThrow(() -> new RuntimeException("User not Found"));
        return user;
    }

    public User getUserByEmailString(String emailString) {
        Optional<User> userOptional = userRepository.findByEmailString(emailString);
        User user = userOptional.orElseThrow(() -> new RuntimeException("User not Found"));
        return user;
    }

    @Transactional
    public void deleteUserById(Long id) {
        userRepository.deleteByUserId(id);
    }
  
    @Transactional
    public void updateUserPassword(Long id, String passwordString) {
        User user = userRepository.findById(id).orElseThrow(() -> new RuntimeException("User not Found"));
        user.setPasswordString(passwordEncoder.encode(passwordString));
    }
    
}
