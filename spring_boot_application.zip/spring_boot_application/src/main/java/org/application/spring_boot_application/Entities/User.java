package org.application.spring_boot_application.Entities;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
@Component
@NoArgsConstructor
@Table(name = "users", indexes = {
    @Index(name = "idx_username", columnList = "username"),
    @Index(name = "idx_password", columnList = "password")
})
public class User {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long userId;

    @Column(name = "username")
    private String usernameString;

    @Column(name = "email")
    private String emailString;

    @Column(name = "password")
    private String passwordString;

    @Column(name = "experience")
    private String experienceString;

    @Column(name = "education")
    private String educationString;

    @Column(name = "projects")
    private List<String> projects = new ArrayList<>();

    @Column(name = "skills")
    private List<String> skills = new ArrayList<>();

    @Column(name = "createdAt")
    private LocalDateTime createdAt;
}
