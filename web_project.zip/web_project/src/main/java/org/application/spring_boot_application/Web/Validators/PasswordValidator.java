package org.application.spring_boot_application.Web.Validators;

import org.application.spring_boot_application.Web.Validations.PasswordValidation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class PasswordValidator implements ConstraintValidator<PasswordValidation, String> {

    private static final String PASSWORD_PATTERN_STRING = "^(?=.*[a-z])(?=.*[A-Z])(?=.*[\\W_]).+$";

    @Override
    public boolean isValid(String passwordString, ConstraintValidatorContext context) {
        if (passwordString != null && passwordString.matches(PASSWORD_PATTERN_STRING)) {
            return true;
        } else {
            return false;
        }
    }
    
}

