package org.application.spring_boot_application.Web.LocaleResolvers;

import java.util.Locale;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.i18n.AcceptHeaderLocaleResolver;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Component
public class CustomLocaleResolver extends AcceptHeaderLocaleResolver {

    @Override
    public Locale resolveLocale(HttpServletRequest request) {
        HttpSession session = request.getSession(false); 
        if (session != null) {
            String lang = (String) session.getAttribute("lang");
            if (lang != null) {
                return Locale.forLanguageTag(lang);
            }
        }
        return super.resolveLocale(request); 
    }
}
