package org.application.spring_boot_application.Config;

import org.application.spring_boot_application.Admin.Services.CustomUserDetailsService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;

import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity(prePostEnabled = true, securedEnabled = true)
public class SecurityConfig {

    private final CustomUserDetailsService customUserDetailsService;

    public SecurityConfig(CustomUserDetailsService customUserDetailsService) {
        this.customUserDetailsService = customUserDetailsService;
    }

    private static final String[] WHITELIST = {
        "/login/**",
        "/db-console/**",
        "/css/**",
        "/fonts/**",
        "/sprites/**",
        "/scripts/**",
        "/uploads/**",
        "/user/signIn",
        "/user/guest"
    };

    @Bean
    SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .authorizeHttpRequests(requests -> requests
                .requestMatchers(WHITELIST).permitAll()
                .requestMatchers("/admin/**").hasAuthority("ACCESS_ADMIN_PANEL")
                .anyRequest().authenticated()
            )
            .formLogin(login -> login
                 .loginPage("/login/")
                 .loginProcessingUrl("/login/authenticate")
                 .usernameParameter("username")
                 .passwordParameter("password")
                 .failureUrl("/login/?error=Bad Credentials")
                 .defaultSuccessUrl("/home/", true)
                 .permitAll())
            .userDetailsService(customUserDetailsService) 
            .sessionManagement(session -> session
                                                .maximumSessions(5)
                                                .maxSessionsPreventsLogin(true))
            .csrf(csrf -> csrf.disable())
            .headers(headers -> headers.frameOptions(frame -> frame.disable()));
    
        return http.build();       
    }

}

