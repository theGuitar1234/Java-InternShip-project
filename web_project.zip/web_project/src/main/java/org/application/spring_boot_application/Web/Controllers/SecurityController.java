package org.application.spring_boot_application.Web.Controllers;

import org.springframework.stereotype.Controller;

import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.RequestMapping;
import jakarta.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.GetMapping;

@Controller
@RequestMapping("/login")
public class SecurityController {

    @GetMapping("/")
    public String login(HttpServletRequest request, Model model) {
        model.addAttribute("error", request.getParameter("error"));
        return "login";
    }

    @GetMapping("/authenticate")
    public String authenticate() {
        return "login";
    }
    
}

