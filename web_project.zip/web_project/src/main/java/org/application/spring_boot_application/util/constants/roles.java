package org.application.spring_boot_application.util.constants;

public enum roles {
    ADMIN(2L, "ADMIN"), 
    USER(1L, "USER");

    private final Long roleId;

    private final String roleString;

    private roles(Long roleId, String roleString) {
        this.roleId = roleId;
        this.roleString = roleString;
    }

    public Long getRoleId() {
        return this.roleId;
    }
    public String getRoleString() {
        return this.roleString;
    }

}
