package org.application.spring_boot_application.Admin.Controllers;

import java.security.Principal;

import org.application.spring_boot_application.Admin.Entities.Role;
import org.application.spring_boot_application.Admin.Entities.User;
import org.application.spring_boot_application.Admin.Services.RoleService;
import org.application.spring_boot_application.Admin.Services.UserService;
import org.application.spring_boot_application.util.constants.roles;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;

@Controller
@RequestMapping("/user")
public class UserController {

    private final UserService userService;

    private final RoleService roleService;

    private final PasswordEncoder passwordEncoder;

    public UserController(UserService userService, RoleService roleService, PasswordEncoder passwordEncoder) {
        this.userService = userService;
        this.roleService = roleService;
        this.passwordEncoder = passwordEncoder;
    }

    @GetMapping("/logout")
    public String logout(Principal principal, HttpServletRequest request) {

        String username = principal.getName();
        System.out.println(username);
        User user = userService.getUserByUsernameString(username);
        userService.deleteUserById(user.getUserId());
        SecurityContextHolder.clearContext();
        request.getSession().invalidate();

        return "redirect:/restricted/";
    }

    @GetMapping("/signIn")
    public String signIn(Model model) {
        model.addAttribute("user", new User());
        return "signIn";
    }

    @PostMapping("/signIn")
    public String signIn(@ModelAttribute @Valid User user, BindingResult bindingResult, Model model) {

        if (bindingResult.hasErrors()) {
            bindingResult.getAllErrors().forEach(error -> 
                System.out.println("Validation error: " + error.getDefaultMessage() + "\n")
            );
            model.addAttribute("user", user);
            return "signIn";
        }

        user.setPasswordString(passwordEncoder.encode(user.getPasswordString()));
        Role roleTemp = roleService.getByRoleNameString(roles.USER.getRoleString());
        user.addRole(roleTemp);
        userService.save(user);
        
        return "redirect:/login/authenticate";
    }
    
}
