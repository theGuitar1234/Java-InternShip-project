package org.application.spring_boot_application.Services;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.application.spring_boot_application.Entities.Authority;
import org.application.spring_boot_application.Entities.Role;
import org.application.spring_boot_application.Entities.User;
//import org.springframework.context.annotation.Lazy;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    private final UserService userService;

    public CustomUserDetailsService(/*@Lazy*/ UserService userService) {
        this.userService = userService;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userService.getUserByUsernameString(username);

        List<GrantedAuthority> grantedAuthorities = new ArrayList<>();

        Set<Role> roles = user.getRoles();

        for (Role role : roles) {
            grantedAuthorities.add(new SimpleGrantedAuthority("ROLE_" + role.getRoleNameString()));
            for (Authority authority : role.getAuthorities()) {
                grantedAuthorities.add(new SimpleGrantedAuthority(authority.getAuthorityNameString()));
            }
        }

        UserDetails userDetails = org.springframework.security.core.userdetails.User.withUsername(user.getUsernameString())
                                                                                        .password(user.getPasswordString())
                                                                                        .authorities(grantedAuthorities)
                                                                                        .build();
        return userDetails;
    }
    
}
