package org.application.spring_boot_application.util;

import io.jsonwebtoken.Jwts;

import java.security.KeyPair;
import java.util.Base64;

public class JwtKeyGenerator {

    public static void main(String[] args) {
        
        KeyPair keyPair = Jwts.SIG.ES384.keyPair().build();

        String base64PrivateKey = Base64.getEncoder().encodeToString(keyPair.getPrivate().getEncoded());
        String base64PublicKey = Base64.getEncoder().encodeToString(keyPair.getPublic().getEncoded());

        System.out.println("JWT Private Key: " + base64PrivateKey);
        System.out.println("JWT Public Key: " + base64PublicKey);
    }

}
