package org.application.spring_boot_application.Services;

import java.time.LocalDateTime;

import java.util.Collection;
import java.util.Optional;

import org.application.spring_boot_application.DTOs.UserDTO;
import org.application.spring_boot_application.Entities.User;
import org.application.spring_boot_application.Models.UserModel;
import org.application.spring_boot_application.Repositories.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import org.springframework.transaction.annotation.Transactional;

import jakarta.validation.Valid;

@Service
public class UserService {
    
    private final UserRepository userRepository;

    private final PasswordEncoder passwordEncoder;

    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public User save(@Valid User user) {
        if (user.getCreatedAt() == null) {
            user.setCreatedAt(LocalDateTime.now());
        }
        if (user.getProfilePhotoPath() == null) {
            user.setProfilePhotoPath("/sprites/profile_picture.jpg");
        }
        User savedUser = userRepository.save(user);
        UserModel.addUser(user);
        return savedUser;
    }

    public void saveAll(User... args) {
        for (User i : args) {
            if (i.getCreatedAt() == null) {
                i.setCreatedAt(LocalDateTime.now());
            }
            userRepository.save(i);
            UserModel.addUser(i);
        }
    }

    public User getUserById(Long id) {
        Optional<User> userOptional = userRepository.findByUserId(id);
        User user = userOptional.orElseThrow(() -> new RuntimeException("User not Found"));
        return user;
    }

    public User getUserByUsernameString(String username) {
        Optional<User> userOptional = userRepository.findByUsernameString(username);
        User user = userOptional.orElseThrow(() -> new RuntimeException("User not Found"));
        return user;
    }

    public User getUserByEmailString(String emailString) {
        Optional<User> userOptional = userRepository.findByEmailString(emailString);
        User user = userOptional.orElseThrow(() -> new RuntimeException("User not Found"));
        return user;
    }

    public Collection<User> getAllUsers() {
        return UserModel.getUserModel().getUserList().values();
    }

    @Transactional
    public void deleteUserById(Long id) {
        userRepository.deleteByUserId(id);
        UserModel.removeUser(id);
    }

    public void deleteUser(User user) {
        userRepository.delete(user);
        UserModel.removeUser(user.getUserId());
    }

    public void deleteAllUsers() {
        userRepository.deleteAll();
        UserModel.removeAllUsers();
    }
  
    @Transactional
    public void updateUserPassword(Long id, String passwordString) {
        User user = userRepository.findById(id).orElseThrow(() -> new RuntimeException("User not Found"));
        
        user.setPasswordString(passwordEncoder.encode(passwordString));

        UserModel.getUser(id).setPasswordString(passwordEncoder.encode(passwordString));
    }

    @Transactional
    public User authenticateUser(UserDTO userDTO) {
        for (User i : UserModel.getUserModel().getUserList().values()) {
            if (i.getEmailString().equals(userDTO.getEmailString()) && passwordEncoder.matches(userDTO.getPasswordString(), i.getPasswordString())) {
                return i;
            }
        }
        return null;
    }

    public boolean existsByUserId(Long id) {
        return userRepository.existsByUserId(id);
    }
    
}
