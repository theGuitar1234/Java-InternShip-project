package org.application.spring_boot_application.util.constants;

public enum roles {
    SUPER_ADMIN(8L, "SUPER_ADMIN"),
    ADMIN(2L, "ADMIN"), 
    MANAGER(4L, "MANAGER"), 
    MODERATOR(5L, "MODERATOR"), 
    EDITOR(3L, "EDITOR"), 
    USER(1L, "USER"), 
    GUEST(6L, "GUEST"), 
    BANNED(7L, "BANNED");

    private final Long roleId;

    private final String roleString;

    private roles(Long roleId, String roleString) {
        this.roleId = roleId;
        this.roleString = roleString;
    }

    public Long getRoleId() {
        return this.roleId;
    }
    public String getRoleString() {
        return this.roleString;
    }

}
