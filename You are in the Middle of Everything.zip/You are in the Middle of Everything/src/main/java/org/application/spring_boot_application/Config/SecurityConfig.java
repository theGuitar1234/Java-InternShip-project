package org.application.spring_boot_application.Config;

import org.application.spring_boot_application.Authenticators.CustomAuthenticationProvider;
import org.application.spring_boot_application.Filters.JwtAuthFilter;
import org.application.spring_boot_application.Services.CustomUserDetailsService;
import org.application.spring_boot_application.util.JwtUtil;
import org.application.spring_boot_application.util.constants.authorities;
//import org.application.spring_boot_application.util.constants.roles;
import org.application.spring_boot_application.util.constants.roles;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.ProviderManager;
//import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
//import org.springframework.security.core.userdetails.User;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
//import org.springframework.security.web.csrf.CookieCsrfTokenRepository;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity(prePostEnabled = true, securedEnabled = true)
public class SecurityConfig {

    private final CustomUserDetailsService customUserDetailsService;

    private final CustomAuthenticationProvider customAuthenticationProvider;

    private final JwtUtil jwtUtil;

    public SecurityConfig(CustomUserDetailsService customUserDetailsService, CustomAuthenticationProvider customAuthenticationProvider, JwtUtil jwtUtil) {
        this.customUserDetailsService = customUserDetailsService;
        this.customAuthenticationProvider = customAuthenticationProvider;
        this.jwtUtil = jwtUtil;
    }

    private static final String[] WHITELIST = {
        "/restricted/**",
        "/db-console/**",
        "/css/**",
        "/fonts/**",
        "/sprites/**",
        "/scripts/**",
        "/uploads/**",
        /*"/user/signIn",*/
        "/user/guest"
    };

    @Bean
    AuthenticationManager authenticationManager() {
        return new ProviderManager(customAuthenticationProvider);
    }

    @Bean
    SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .authorizeHttpRequests(requests -> requests
                .requestMatchers(WHITELIST).permitAll()
                .requestMatchers("/").hasAnyRole(roles.ADMIN.getRoleString(), roles.SUPER_ADMIN.getRoleString())
                .requestMatchers("/admin/**").hasAuthority(authorities.ACCESS_ADMIN_PANEL.getAuthorityString())
                .requestMatchers("/editor/**").hasRole(roles.EDITOR.getRoleString())
                //.requestMatchers("/**").permitAll()
                .anyRequest().authenticated()
            )
            // .formLogin(Customizer.withDefaults())
            // .formLogin(login -> login
            //      .loginPage("/restricted/")
            //      .loginProcessingUrl("/restricted/authenticate")
            //      .usernameParameter("username")
            //      .passwordParameter("password")
            //      .failureUrl("/restricted/?error=Bad Credentials")
            //      .defaultSuccessUrl("/home/", true)
            //      .permitAll())
            //.logout(Customizer.withDefaults())
            // .logout(logout -> logout
            //                         .logoutUrl("/user/logout")
            //                         .invalidateHttpSession(true)
            //                         .deleteCookies("JSESSIONID"))
            .userDetailsService(customUserDetailsService)
            .authenticationManager(authenticationManager())
            .rememberMe(me -> me.rememberMeParameter("remember-me"))
            //.securityContext(securityContext -> securityContext.requireExplicitSave(true))
            .sessionManagement(session -> session
                                                 .sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                                                 //.maximumSessions(5)
                                                 //.maxSessionsPreventsLogin(true))
            .addFilterBefore(new JwtAuthFilter(jwtUtil), UsernamePasswordAuthenticationFilter.class)
            .csrf(csrf -> csrf.disable())
            // .csrf(csrf -> csrf
            //                   .csrfTokenRepository(CookieCsrfTokenRepository.withHttpOnlyFalse()))
            //.csrf(csrf -> csrf
            //    .ignoringRequestMatchers("/db-console/**"))
            .headers(headers -> headers.frameOptions(frame -> frame.disable()))
            .exceptionHandling(exception -> exception
                .authenticationEntryPoint((request, response, authException) -> response.sendRedirect("/restricted/"))
            );
    
        return http.build();       
    }

    // @Bean
    // InMemoryUserDetailsManager userDetailsService() {
    //     UserDetails admin = User.withUsername("admin")
    //                                 .password(passwordEncoder.encode("1234"))
    //                                 .roles(roles.ADMIN.getRoleString())
    //                                 .build();

    //     UserDetails user = User.withUsername("user")
    //                                 .password(passwordEncoder.encode("1234"))
    //                                 .roles(roles.USER.getRoleString())
    //                                 .build();

    //     return new InMemoryUserDetailsManager(admin, user);
    // }

}

