package org.application.spring_boot_application.Services;

import java.time.Duration;
import java.time.Instant;
import java.util.Optional;

import org.application.spring_boot_application.Entities.OtpCode;
import org.application.spring_boot_application.Entities.PasswordResetToken;
import org.application.spring_boot_application.Entities.User;
import org.application.spring_boot_application.Models.UserModel;
import org.application.spring_boot_application.Repositories.OtpCodeRepository;
import org.application.spring_boot_application.Repositories.PasswordResetTokenRepository;
import org.application.spring_boot_application.Repositories.UserRepository;
import org.application.spring_boot_application.util.OtpGenerator;
import org.application.spring_boot_application.util.PasswordResetTokenGenerator;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jakarta.mail.MessagingException;
import jakarta.servlet.http.HttpServletRequest;

@Service
public class PasswordResetService {

    private final PasswordResetTokenRepository passwordResetTokenRepository;
    
    private final OtpCodeRepository otpCodeRepository;

    private final UserRepository userRepository;

    private final EmailService emailService;

    private final PasswordEncoder passwordEncoder;

    public PasswordResetService(PasswordResetTokenRepository passwordResetTokenRepository, OtpCodeRepository otpCodeRepository, UserRepository userRepository, EmailService emailService, PasswordEncoder passwordEncoder) {
        this.passwordResetTokenRepository = passwordResetTokenRepository;
        this.otpCodeRepository = otpCodeRepository;
        this.userRepository = userRepository;
        this.emailService = emailService;
        this.passwordEncoder = passwordEncoder;
    }

    public void createPasswordResetToken(String email) throws MessagingException {
        Optional<User> userOptional = userRepository.findByEmailString(email);

        if (userOptional.isPresent()) {
            User user = userOptional.get();
            String token = PasswordResetTokenGenerator.generateToken();
            Instant expiration_date = Instant.now().plus(Duration.ofMinutes(15));

            PasswordResetToken passwordResetToken = new PasswordResetToken();
            passwordResetToken.setEmail(email);
            passwordResetToken.setToken(token);
            passwordResetToken.setExpirationDate(expiration_date);
            passwordResetToken.setUser(user);
            user.setPasswordResetToken(passwordResetToken);

            passwordResetTokenRepository.save(passwordResetToken);

            emailService.sendResetLink(user.getEmailString(), token);
        } else {
            return;
        }

    }

    public boolean isTokenValid(String token) {
        Optional<PasswordResetToken> resetTokenOptional = passwordResetTokenRepository.findByToken(token);
        PasswordResetToken passwordResetToken = resetTokenOptional.orElseThrow(() -> new RuntimeException("Token not Found"));

        if (passwordResetToken != null && passwordResetToken.getExpirationDate().isAfter(Instant.now())) {
            return true;
        } else {
            return false;
        }
    }

    @Transactional
    public boolean tokenResetPassword(String token, String password, HttpServletRequest request) {
        Optional<PasswordResetToken> resetTokenOptional = passwordResetTokenRepository.findByToken(token);
        PasswordResetToken passwordResetToken = resetTokenOptional.orElseThrow(() -> new RuntimeException("Token not Found"));

        if (passwordResetToken == null || !isTokenValid(token)) {
            return false;
        }
    
        User user = passwordResetToken.getUser();
        user.setPasswordString(passwordEncoder.encode(password));
        userRepository.save(user);

        UserModel.getUser(user.getUserId()).setPasswordString(passwordEncoder.encode(password));

        SecurityContextHolder.clearContext();
        request.getSession().invalidate();
    
        passwordResetTokenRepository.delete(passwordResetToken); 
        user.setPasswordResetToken(null);
        
        return true;
    }

    public void createOtpCode(String email) throws MessagingException {
        Optional<User> userOptional = userRepository.findByEmailString(email);

        if (userOptional.isPresent()) {
            User user = userOptional.get();
            String otpCode = OtpGenerator.generateOtp();
            Instant expiration_date = Instant.now().plus(Duration.ofMinutes(1));

            OtpCode otpCodeTemp = new OtpCode();
            otpCodeTemp.setEmail(email);
            otpCodeTemp.setOtpCode(otpCode);
            otpCodeTemp.setExpirationDate(expiration_date);
            otpCodeTemp.setUser(user);
            user.setOtpCode(otpCodeTemp);

            otpCodeRepository.save(otpCodeTemp);

            emailService.sendOtpCode(email, otpCode);
        } else {
            return;
        }
    }

    public boolean isOtpValid(String email, String otpCode) {
        Optional<OtpCode> otpCodeOptional = otpCodeRepository.findByEmailAndOtpCode(email, otpCode);
        OtpCode otpCodeTemp = otpCodeOptional.orElseThrow(() -> new RuntimeException("Code not Found"));

        if (otpCodeTemp != null && otpCodeTemp.getExpirationDate().isAfter(Instant.now())) {
            return true;
        } else {
            return false;
        }
    }

    @Transactional
    public boolean otpResetPassword(String email, String otpCode, String password, HttpServletRequest request) {
        Optional<OtpCode> otpCodeOptional = otpCodeRepository.findByEmailAndOtpCode(email, otpCode);
        OtpCode otpCodeTemp = otpCodeOptional.orElseThrow(() -> new RuntimeException("Code not Found"));

        if (otpCodeTemp == null || !isOtpValid(email, otpCode)) {
            return false;
        }
    
        User user = otpCodeTemp.getUser();
        user.setPasswordString(passwordEncoder.encode(password));
        userRepository.save(user);

        UserModel.getUser(user.getUserId()).setPasswordString(passwordEncoder.encode(password));

        SecurityContextHolder.clearContext();
        request.getSession().invalidate();
    
        otpCodeRepository.delete(otpCodeTemp);
        user.setOtpCode(null);
        
        return true;
    }

}
