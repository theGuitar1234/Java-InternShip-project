package org.application.spring_boot_application.Entities;

import java.time.LocalDateTime;

import org.springframework.stereotype.Component;

//import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@JacksonXmlRootElement(localName = "Post")

@Entity
@Getter
@Setter
@Builder
@Component
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "Posts")
public class Post {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long postId;

    @Column(name = "postTitle", nullable = true, unique = false)
    private String postTitleString;

    @Column(name = "postBody", nullable = true, unique = false, columnDefinition = "TEXT")
    @Lob
    private String postBodyString;

    @Column
    private LocalDateTime createdAt;

    //@JsonIgnore
    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Override
    public String toString() {
        return "Post [post_id=" + postId + ", postTitleString=" + postTitleString + ", postBodyString="
                + postBodyString + ", createdAt=" + createdAt + "]";
    }

}


