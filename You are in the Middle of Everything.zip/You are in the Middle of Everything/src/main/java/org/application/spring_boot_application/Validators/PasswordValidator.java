package org.application.spring_boot_application.Validators;

import org.application.spring_boot_application.Validations.PasswordValidation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class PasswordValidator implements ConstraintValidator<PasswordValidation, String> {

    private static final String PASSWORD_PATTERN_STRING = "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$";

    @Override
    public boolean isValid(String passwordString, ConstraintValidatorContext context) {
        if (passwordString != null && passwordString.matches(PASSWORD_PATTERN_STRING)) {
            return true;
        } else {
            return false;
        }
    }
    
}
