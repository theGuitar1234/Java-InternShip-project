package org.application.spring_boot_application.Controllers;

import java.util.Set;

import org.application.spring_boot_application.Entities.Role;
import org.application.spring_boot_application.Entities.User;
import org.application.spring_boot_application.Models.UserModel;
import org.application.spring_boot_application.Services.RoleService;
import org.application.spring_boot_application.Services.UserService;
import org.application.spring_boot_application.util.constants.roles;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;

import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.validation.Valid;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
@RequestMapping("/admin")
public class AdminController {
    
    private final UserService userService;

    private final RoleService roleService;

    private final PasswordEncoder passwordEncoder;

    public AdminController(UserService userService, RoleService roleService, PasswordEncoder passwordEncoder) {
        this.userService = userService;
        this.roleService = roleService;
        this.passwordEncoder = passwordEncoder;
    }

    @GetMapping("/")
    @PreAuthorize("hasAuthority('ACCESS_ADMIN_PANEL')")
    public String admin(Model model) {
        model.addAttribute("users", UserModel.getUserModel().getUserList().values());
        return "admin";
    }

    @PreAuthorize("hasAnyRole('ADMIN', 'SUPER_ADMIN')")
    @GetMapping("/signIn")
    public String signIn(Model model) {
        System.out.println("The SUPER_ADMIN has arrived!" + SecurityContextHolder.getContext().getAuthentication().getAuthorities().toString());
        model.addAttribute("user", new User());
        return "sign_in";
    }

    @PreAuthorize("hasAuthority('ADD_A_USER')")
    @PostMapping("/signIn")
    public String signIn(@ModelAttribute @Valid User user, BindingResult bindingResult, Model model) {

        if (bindingResult.hasErrors()) {
            bindingResult.getAllErrors().forEach(error -> 
                System.out.println("Validation error: " + error.getDefaultMessage() + "\n")
            );
            model.addAttribute("user", user);
            return "sign_in";
        }

        user.setPasswordString(passwordEncoder.encode(user.getPasswordString()));
        userService.save(user);
        roleService.addRolesToUser(user.getUsernameString(), Set.of(roles.USER.getRoleId()));

        return "redirect:/restricted/";
    }

    @GetMapping("/delete/{id}")
    @PreAuthorize("hasAuthority('DELETE_ANY_USER')")
    public String deleteUser(@PathVariable Long id) {
        userService.deleteUserById(id);
        return "redirect:/admin/";
    }

    @PostMapping("/add_role")
    @PreAuthorize("hasAnyRole('ADMIN', 'SUPER_ADMIN')")
    public String addRole(@RequestParam Long userId, @RequestParam String role) {
        User user = userService.getUserById(userId);
        Role roleTemp = roleService.getByRoleNameString(role);
        roleService.addRolesToUser(user.getUsernameString(), Set.of(roleTemp.getRoleId()));
        return "redirect:/admin/";
    }

    @PreAuthorize("hasAnyRole('ADMIN', 'SUPER_ADMIN')")
    @PostMapping("/ban_or_unban_user/{userId}")
    public String banOrUnbanUser(@PathVariable("userId") Long userId) {
        User user = userService.getUserById(userId);
        for (Role role : user.getRoles()) {
            if ("BANNED".equals(role.getRoleNameString())) {
                roleService.removeRoleFromUser(user.getUsernameString(), roles.BANNED.getRoleId());
                roleService.addRolesToUser(user.getUsernameString(), Set.of(roles.USER.getRoleId()));
                return "redirect:/admin/";
            } else {
                for (Role roleTemp : user.getRoles()) {
                    roleService.removeRoleFromUser(user.getUsernameString(), roleTemp.getRoleId());
                }
                roleService.addRolesToUser(user.getUsernameString(), Set.of(roles.BANNED.getRoleId()));
                return "redirect:/admin/";
            }
        }
        return "redirect:/admin/";
    }

    
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    @PostMapping("/resetPassword")
    public String resetPassword(@RequestParam Long userId, @RequestParam String password) {
        userService.updateUserPassword(userId, password);
        return "redirect:/admin/";
    }
    
}
