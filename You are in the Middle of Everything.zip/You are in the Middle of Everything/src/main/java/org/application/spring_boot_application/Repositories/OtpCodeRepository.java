package org.application.spring_boot_application.Repositories;

import java.util.Optional;

import org.application.spring_boot_application.Entities.OtpCode;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OtpCodeRepository extends JpaRepository<OtpCode, Long> {
    Optional<OtpCode> findByEmailAndOtpCode(String email, String otpCode);
}