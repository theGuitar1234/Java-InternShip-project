package org.application.spring_boot_application.Controllers;

import java.security.Principal;

import org.application.spring_boot_application.Entities.Post;
import org.application.spring_boot_application.Entities.User;
import org.application.spring_boot_application.Models.PostModel;
import org.application.spring_boot_application.Models.UserModel;
import org.application.spring_boot_application.Services.PostService;
import org.springframework.stereotype.Controller;

import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
@RequestMapping("/post")
public class PostController {

    private final PostService postService;

    public PostController(PostService postService) {
        this.postService = postService;
    }

    @GetMapping("/view_post/{id}")
    public String view_post(@PathVariable Long id, Model model, Principal principal) {
        Post post = PostModel.getPost(id);
        boolean isAuthor = false;
        if (principal.getName().equals(post.getUser().getUsernameString())) {
            isAuthor = true;
        }
        model.addAttribute("post", post);
        model.addAttribute("isAuthor", isAuthor);

        return "view_post";
    }

    @GetMapping("/edit_post/{id}")
    public String editPost(@PathVariable Long id, Model model) {
        model.addAttribute("id", id);
        model.addAttribute("post", PostModel.getPost(id));
        return "edit_post";
    }

    @PostMapping("/edit_post/{id}")
    public String editPost(@PathVariable Long id, @RequestParam String postTitle, @RequestParam String content, Model model) {
        postService.updatePost(id, postTitle, content);
        return "redirect:/post/view_post/" + id;
    }
    

    @GetMapping("/add_post/{userId}")
    public String addPost(Model model, @PathVariable Long userId) {
        model.addAttribute("post", new Post());
        model.addAttribute("userId", userId);
        return "add_post";
    }

    @PostMapping("/add_post/{userId}")
    public String addPost(@ModelAttribute Post post, @PathVariable Long userId, Model model) {
        UserModel.getUser(userId).addPost(post);
        postService.save(post);
        return "redirect:/post/view_post/" + post.getPostId();
    }
    
    @GetMapping("/delete_post/{id}")
    public String deletePost(@PathVariable Long id, Model model) {
        model.addAttribute("user", PostModel.getPost(id).getUser());
        User user = PostModel.getPost(id).getUser();
        if (user != null) {
            user.getPosts().remove(PostModel.getPost(id));
        }
        PostModel.removePost(id);
        postService.deletepost(id);
        System.out.println(PostModel.getPostModel().getPostList());
        return "redirect:/post/posts";
    }

    @GetMapping("/posts")
    public String posts(Model model) {
        model.addAttribute("posts", PostModel.getPostModel().getPostList().values());
        System.out.println(PostModel.getPostModel().getPostList());
        return "posts";
    }
    
}
