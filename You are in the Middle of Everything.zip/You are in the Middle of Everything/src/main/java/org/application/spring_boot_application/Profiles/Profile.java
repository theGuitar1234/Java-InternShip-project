package org.application.spring_boot_application.Profiles;

import java.time.LocalDate;
import java.time.LocalDateTime;

import org.application.spring_boot_application.Validations.EmailValidation;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@Component
@NoArgsConstructor
@AllArgsConstructor
public class Profile {
    
    private Long userId;
    
    private String usernameString;
   
    private String firstnameString;

    private String surnameString;

    private int age;

    @EmailValidation
    private String emailString;

    private String phoneNumberString;

    private String genderString;

    @DateTimeFormat(pattern="yyyy-MM-dd")
    private LocalDate dateOfBirth;

    private LocalDateTime createdAt;

}
