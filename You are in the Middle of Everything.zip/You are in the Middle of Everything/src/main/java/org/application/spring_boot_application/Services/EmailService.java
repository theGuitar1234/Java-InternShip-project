package org.application.spring_boot_application.Services;

import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;

@Service
public class EmailService {

    private final JavaMailSender javaMailSender;

    public EmailService(JavaMailSender javaMailSender) {
        this.javaMailSender = javaMailSender;
    }

    private void sendEmail(String to, String subject, String content) throws MessagingException {
        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage, true);

        mimeMessageHelper.setTo(to);
        mimeMessageHelper.setSubject(subject);
        mimeMessageHelper.setText(content, true);

        javaMailSender.send(mimeMessage);
    }

    public void sendResetLink(String to, String token) throws MessagingException {
        String resetURL = "http://localhost:8080/restricted/token_reset_password?token=" + token;
        String subject = "Here is your link Rookie";
        String content = "<p>Seriously, get your shit together!</p>" + "<a href=" + resetURL + ">Get all your shit, put it in a backpack, get your shit together!</a>";

        sendEmail(to, subject, content);
    }

    public void sendOtpCode(String to, String otpCode) throws MessagingException {
        String subject = "Here is your code Rookie";
        String content = "Seriously, get your shit together! : " + otpCode;

        sendEmail(to, subject, content);
    }
}