package org.application.spring_boot_application.Entities;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.application.spring_boot_application.Validations.EmailValidation;
import org.springframework.format.annotation.DateTimeFormat;
//import org.application.spring_boot_application.Validatiors.PasswordValidatior;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@Component
@NoArgsConstructor
@Table(name = "Users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long userId;

    @Column(name = "username", nullable = false, unique = true)
    private String usernameString;

    @Column(name = "firstname", nullable = true, unique = false)
    private String firstnameString;

    @Column(name = "surname", nullable = true, unique = false)
    private String surnameString;

    @Column(nullable = true, unique = false)
    private int age;
    
    @EmailValidation
    @Column(name = "email", unique = true)
    private String emailString;

    //@PasswordValidatior
    @Column(name = "password")
    private String passwordString;

    @Column(name = "phone_number")
    private String phoneNumberString;

    @Column(name = "gender")
    private String genderString;

    @Column(name = "date_of_birth")
    @DateTimeFormat(pattern="yyyy-MM-dd")
    private LocalDate dateOfBirth;

    @Column(name = "profile_photo")
    private String profilePhotoPath;

    @Column(nullable = false)
    private LocalDateTime createdAt;

    @JsonIgnore
    @OneToOne(mappedBy = "user", cascade = CascadeType.ALL)
    private PasswordResetToken passwordResetToken;

    @JsonIgnore
    @OneToOne(mappedBy = "user", cascade = CascadeType.ALL)
    private OtpCode otpCode;

    @JsonIgnore
    @OneToMany(mappedBy = "user", cascade = CascadeType.PERSIST, orphanRemoval = true, fetch = FetchType.LAZY)
    private List<Post> posts = new ArrayList<>();

    public void addPost(Post post) {
        posts.add(post);
        post.setUser(this);
    }

    @JsonIgnore
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable (
        name = "user_roles",
        joinColumns = @JoinColumn(name = "userId"),
        inverseJoinColumns = @JoinColumn(name = "roleId")
    )
    private Set<Role> roles = new HashSet<>();

    public void addRole(Role role) {
        roles.add(role);
    }

    public void removeRole(Role role) {
        roles.remove(role);
    }

    @JsonIgnore
    @OneToMany(mappedBy = "user", cascade = CascadeType.PERSIST, orphanRemoval = true, fetch = FetchType.LAZY)
    private List<Album> albums = new ArrayList<>();

    public void addAlbum(Album album) {
        albums.add(album);
        album.setUser(this);
    }

    @Override
    public String toString() {
        return "User [userId=" + userId + ", usernameString=" + usernameString + ", firstnameString=" + firstnameString
                + ", surnameString=" + surnameString + ", age=" + age + ", emailString=" + emailString
                + ", passwordString=" + passwordString + ", phoneNumberString=" + phoneNumberString + ", createdAt="
                + createdAt + "]";
    }

}

