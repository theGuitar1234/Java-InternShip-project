package org.application.spring_boot_application.DTOs;

import org.springframework.stereotype.Component;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema.RequiredMode;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Getter
@Setter
@ToString
@Component
@NoArgsConstructor
@AllArgsConstructor
public class AlbumPayloadDTO {

    @NotBlank
    @Schema(description = "This is the Title of the Album", example = "title", requiredMode = RequiredMode.REQUIRED)
    private String albumTitleString;

    @NotBlank
    @Schema(description = "This is the Description of the Album", example = "description", requiredMode = RequiredMode.NOT_REQUIRED)
    private String descriptionString;
}
