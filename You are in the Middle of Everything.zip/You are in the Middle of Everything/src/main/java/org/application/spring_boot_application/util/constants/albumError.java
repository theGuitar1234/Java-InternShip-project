package org.application.spring_boot_application.util.constants;

public enum albumError {
    ADD_ALBUM_ERROR("ADD_ALBUM_ERROR"),
    ALBUM_ERROR("ALBUM_ERROR");

    private String albumErrorString;

    private albumError(String albumErrorString) {
        this.albumErrorString = albumErrorString;
    }

    public String getAlbumErrorString() {
        return this.albumErrorString;
    }
}
