package org.application.spring_boot_application.Config;

import org.application.spring_boot_application.Interceptors.RequestInterceptor;

import org.springframework.context.annotation.Configuration;

import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.i18n.LocaleChangeInterceptor;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    private final RequestInterceptor requestInterceptor;

    private final LocaleChangeInterceptor localeChangeInterceptor;

    public WebConfig(RequestInterceptor requestInterceptor, LocaleChangeInterceptor localeChangeInterceptor) {
        this.requestInterceptor = requestInterceptor;
        this.localeChangeInterceptor = localeChangeInterceptor;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(requestInterceptor);//.addPathPatterns("/index/test").excludePathPatterns("/");
        registry.addInterceptor(localeChangeInterceptor);
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/uploads/**")
                .addResourceLocations("file:uploads/");
        registry.addResourceHandler("/i18n/**")
                .addResourceLocations("file:i18n/");
        registry.addResourceHandler("/photos/**")
                .addResourceLocations("file:photos/");  
        registry.addResourceHandler("/thumbnails/**")
                .addResourceLocations("file:thumbnails/");
    }

}


