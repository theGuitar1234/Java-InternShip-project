package org.application.spring_boot_application.util.constants;

public enum albumSuccess {
    ALBUM_ADDED("ALBUM_ADDED");

    private String albumSuccessString;

    private albumSuccess(String albumSuccessString) {
        this.albumSuccessString = albumSuccessString;
    }

    public String getAlbumSuccessString() {
        return this.albumSuccessString;
    }
}
