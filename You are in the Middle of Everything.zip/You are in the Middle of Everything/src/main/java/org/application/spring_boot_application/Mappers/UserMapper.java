package org.application.spring_boot_application.Mappers;

import org.application.spring_boot_application.DTOs.UserDTO;
import org.application.spring_boot_application.Entities.User;
import org.application.spring_boot_application.Models.UserModel;
import org.application.spring_boot_application.Profiles.Profile;
import org.springframework.stereotype.Component;

@Component
public class UserMapper {
    public static UserDTO toUserDTO(User user) {
        if (user != null) {
            return new UserDTO(user.getUserId(), user.getEmailString(), user.getUsernameString(), user.getPasswordString());
        }
        return null;
    }

    public static Profile toProfile(User user) {
        if (user != null) {
            return new Profile(user.getUserId(), user.getUsernameString(), user.getFirstnameString(), user.getSurnameString(), user.getAge(), user.getEmailString(), user.getPhoneNumberString(), user.getGenderString(), user.getDateOfBirth(), user.getCreatedAt());
        }
        return null;
    }

    public static User getEntityUserFromDTO(UserDTO userDTO) {
        return UserModel.getUser(userDTO.getUser_id());
    }

    public static User getEntityUserFromProfile(Profile album) {
        return UserModel.getUser(album.getUserId());
    }
}
