package org.application.spring_boot_application.Filters;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

import org.application.spring_boot_application.Controllers.SecurityController;
import org.application.spring_boot_application.util.JwtUtil;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.JwtException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.web.filter.OncePerRequestFilter;

@Component
public class JwtAuthFilter extends OncePerRequestFilter {

    private final JwtUtil jwtUtil;

    public JwtAuthFilter(JwtUtil jwtUtil) {
        this.jwtUtil = jwtUtil;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws ServletException, IOException {
        HttpServletRequest HttpRequest = (HttpServletRequest) request;
        HttpServletResponse HttpResponse = (HttpServletResponse) response;

        if (HttpRequest.getRequestURI().startsWith("/css") || 
            HttpRequest.getRequestURI().startsWith("/scripts") ||
            HttpRequest.getRequestURI().startsWith("/sprites") ||
            HttpRequest.getRequestURI().startsWith("/fonts") ||
            HttpRequest.getRequestURI().startsWith("/restricted") ||
            HttpRequest.getRequestURI().startsWith("/db-console") ||
            HttpRequest.getRequestURI().startsWith("/uploads") ||
            HttpRequest.getRequestURI().startsWith("/user/signIn") ||
            HttpRequest.getRequestURI().startsWith("/user/guest")) {
            chain.doFilter(request, response);
            return;
        }

        if (HttpRequest.getCookies() == null) {
            HttpResponse.sendRedirect("/restricted/");
            return;
        }

        String token = null;
        
        for (Cookie i : HttpRequest.getCookies()) {
            if ("jwt".equals(i.getName())) {
                token = i.getValue();
                break;
            }
        }

        try {
            if (token == null || !jwtUtil.isValid(token, jwtUtil.extractUsername(token))) {
                SecurityContextHolder.clearContext();

                Cookie cookie = new Cookie("jwt", null);
                cookie.setHttpOnly(true);
                cookie.setSecure(true);
                cookie.setPath("/");
                cookie.setMaxAge(0);
                HttpResponse.addCookie(cookie);

                HttpResponse.sendRedirect("/restricted/");
                return;
            } else {
                SecurityContextHolder.getContext().setAuthentication(SecurityController.getCachedAuthentication());
                chain.doFilter(request, response);
            }
        } catch (JwtException | IllegalArgumentException | InvalidKeySpecException | NoSuchAlgorithmException e) {
            HttpResponse.sendRedirect("/restricted/");
        }
    }
    
}

