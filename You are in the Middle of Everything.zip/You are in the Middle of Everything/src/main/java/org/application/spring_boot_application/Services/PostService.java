package org.application.spring_boot_application.Services;

import java.time.LocalDateTime;
import java.util.Collection;

import org.application.spring_boot_application.Entities.Post;
import org.application.spring_boot_application.Models.PostModel;
import org.application.spring_boot_application.Repositories.PostRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.springframework.transaction.annotation.Transactional;

@Service
public class PostService {
    
    @Autowired
    private final PostRepository postRepository;

    public PostService(PostRepository postRepository) {
        this.postRepository = postRepository;
    }

    public Post save(Post post) {
        if (post.getCreatedAt() == null) {
            post.setCreatedAt(LocalDateTime.now());
        }
        Post savedPost = postRepository.save(post);
        PostModel.addPost(post);
        return savedPost;
    }

    public Post getPostById(Long id) {
        return postRepository.findById(id).orElseThrow(() -> new RuntimeException("post not Found"));
    }

    public Collection<Post> getAllPosts() {
        //return postRepository.findAll();
        return PostModel.getPostModel().getPostList().values();
    }

    public void deletepost(Long id) {
        postRepository.deleteById(id);
        //PostModel.removePost(id);
    }

    public void deleteAllposts() {
        postRepository.deleteAll();
        PostModel.removeAllposts();
    }

    @Transactional
    public void updatePost(Long id, String postTitleString, String postBodyString) {
        Post post = postRepository.findById(id).orElseThrow(() -> new RuntimeException("Post not Found"));

        post.setPostTitleString(postTitleString);
        post.setPostBodyString(postBodyString);

        PostModel.getPost(id).setPostTitleString(postTitleString);
        PostModel.getPost(id).setPostBodyString(postBodyString);
    }
}
