package org.application.spring_boot_application.Controllers;

import org.application.spring_boot_application.Models.PostModel;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
@RequestMapping("/editor")
public class EditorController {

    @GetMapping("/")
    public String editor(Model model) {
        model.addAttribute("posts", PostModel.getPostModel().getPostList().values());
        return "editor";
    }
    
}
