package org.application.spring_boot_application.Models;

import java.util.HashMap;
import java.util.Map;

import org.application.spring_boot_application.Entities.User;
import org.springframework.stereotype.Component;

@Component
public class UserModel {
    private static UserModel userModel;
    private Map<Long, User> userList;
    
    public static UserModel getUserModel() {
        if (userModel == null) {
            userModel = new UserModel();
            return userModel;
        } else {
            return userModel;
        }
    }

    public Map<Long, User> getUserList() {
        if (userList == null) {
            userList = new HashMap<>();
            return userList;
        } else {
            return userList;
        }
    }

    public static void addUser(User user) {
        if (user != null) {
            UserModel.getUserModel().getUserList().put(user.getUserId(), user);
        }
    }

    public static User getUser(Long id) {
        return UserModel.getUserModel().getUserList().get(id);
    }

    public static void removeUser(Long id) {
        if (UserModel.getUser(id) != null) {
            UserModel.getUserModel().getUserList().remove(id);
        }
    }

    public static void removeAllUsers() {
        if (!UserModel.getUserModel().getUserList().isEmpty()) {
            UserModel.getUserModel().getUserList().clear();
        }
    }
}
