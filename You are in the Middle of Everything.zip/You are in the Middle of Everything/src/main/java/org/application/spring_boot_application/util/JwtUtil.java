package org.application.spring_boot_application.util;

import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;

import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

import java.util.Base64;
import java.util.Date;

import org.application.spring_boot_application.util.constants.jwtkeys;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.InvalidKeyException;
import io.jsonwebtoken.security.Keys;

@Component
public class JwtUtil {

    private static final String PRIVATE_KEY_STRING = jwtkeys.JWT_PRIVATE_KEY.getJwtKeyString();

    private static final String PUBLIC_KEY_STRING = jwtkeys.JWT_PUBLIC_KEY.getJwtKeyString();

    private static final long EXPIRATION_DATE = 60*60*1000;

    public long getExpirationDate() {
        return EXPIRATION_DATE;
    }

    private static PrivateKey getPrivateSigningKey() throws NoSuchAlgorithmException, InvalidKeySpecException {
        byte[] keyBytes = Base64.getDecoder().decode(PRIVATE_KEY_STRING);
        KeyFactory keyFactory = KeyFactory.getInstance("EC");
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(keyBytes);
        PrivateKey privateKey = keyFactory.generatePrivate(keySpec);
        return Keys.builder(privateKey).build();
    }

    private static PublicKey getPublicSigningKey() throws InvalidKeySpecException, NoSuchAlgorithmException {
        byte[] keyBytes = Base64.getDecoder().decode(PUBLIC_KEY_STRING);
        KeyFactory keyFactory = KeyFactory.getInstance("EC");
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(keyBytes);
        PublicKey publicKey = keyFactory.generatePublic(keySpec);
        return publicKey;
    }

    public String generateToken(String username) throws InvalidKeyException, NoSuchAlgorithmException, InvalidKeySpecException {
        return Jwts
                    .builder()
                    .subject(username)
                    .issuedAt(new Date())
                    .expiration(new Date(System.currentTimeMillis() + EXPIRATION_DATE))
                    .signWith(getPrivateSigningKey(), Jwts.SIG.ES384)
                    .compact();
    }

    public Claims validateToken(String token) throws JwtException, IllegalArgumentException, InvalidKeySpecException, NoSuchAlgorithmException  {
        return Jwts
                    .parser()
                    .verifyWith(getPublicSigningKey())
                    .build()
                    .parseSignedClaims(token) 
                    .getPayload(); 
    }    

    public String extractUsername(String token) throws JwtException, IllegalArgumentException, InvalidKeySpecException, NoSuchAlgorithmException {
        Claims claim = validateToken(token);
        return claim.getSubject();
    }

    public boolean isExpired(String token) throws JwtException, IllegalArgumentException, InvalidKeySpecException, NoSuchAlgorithmException {
        Claims claims = validateToken(token);
        Date date = new Date(System.currentTimeMillis());
        if (date.after(claims.getExpiration())) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isValid(String token, String username) throws JwtException, IllegalArgumentException, InvalidKeySpecException, NoSuchAlgorithmException {
        if (extractUsername(token).equals(username) && !isExpired(token)) {
            return true;
        } else {
            return false;
        }
    }

}

