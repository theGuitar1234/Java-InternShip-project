package org.application.spring_boot_application.GlobalExceptionHandlers;

import java.time.LocalDateTime;

import javax.naming.AuthenticationException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
//import org.springframework.web.bind.annotation.RestControllerAdvice;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(Exception.class)
    public String handleGlobalException(Exception e, Model model) {
        model.addAttribute("response", ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                                                   .header("Content-Type", "text/html")
                                                                   .body("Something went wrong : " + e.getMessage() + " " + e.getStackTrace()));
        model.addAttribute("time", LocalDateTime.now());
        return "error";
    }

    @ExceptionHandler(RuntimeException.class)
    public String handleGlobalRuntimeException(RuntimeException e, Model model) {
        model.addAttribute("response", ResponseEntity.status(HttpStatus.NOT_FOUND)
                                                                   .header("Content-Type", "text/html")
                                                                   .body("Runtime Exception Happened : " + e.getMessage() + " " + e.getStackTrace()));
        model.addAttribute("time", LocalDateTime.now());
        return "error";
    }

    @ExceptionHandler(AuthenticationException.class)
    public String handleAuthenticationException(AuthenticationException e) {
        return "redirect:/restricted/?error=" + e.getMessage();
    }

    @ExceptionHandler(BadCredentialsException.class)
    public String handleBadCredentialsException(BadCredentialsException e) {
        return "redirect:/restricted/?error=" + e.getMessage();
    }

}
