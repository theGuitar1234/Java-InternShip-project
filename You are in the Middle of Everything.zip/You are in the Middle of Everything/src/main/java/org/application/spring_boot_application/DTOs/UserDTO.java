package org.application.spring_boot_application.DTOs;

import org.application.spring_boot_application.Validations.EmailValidation;
//import org.application.spring_boot_application.Validations.PasswordValidation;
import org.springframework.stereotype.Component;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema.RequiredMode;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Component
@NoArgsConstructor
@AllArgsConstructor
public class UserDTO {

    private Long user_id;

    @Schema(name = "email_address", description = "Meant to store the email credential during the temporary authentication, demands validation", example = "example@gmail.com", requiredMode = RequiredMode.REQUIRED)
    @EmailValidation
    private String emailString;

    private String usernameString;

    @Schema(name = "password", description = "Meant to store the password credential during the temporary authentication, demands validation", example = "Asdqwethy123456@", requiredMode = RequiredMode.REQUIRED)
    //@PasswordValidation
    private String passwordString;
}
