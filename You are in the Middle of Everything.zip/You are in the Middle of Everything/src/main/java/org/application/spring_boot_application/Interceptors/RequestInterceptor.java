package org.application.spring_boot_application.Interceptors;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class RequestInterceptor implements HandlerInterceptor {

    private static final int MAX_REQUESTS = 60;

    private static ConcurrentHashMap<String, Integer> requestCounts = new ConcurrentHashMap<>();

    private static long start;

    private static long beginning;

    private static final List<String> STATIC_RESOURCES = List.of(
        "/css/", 
        "/scripts/", 
        "/images/", 
        "/fonts/", 
        "/sprites/", 
        "/fonts/",
        "/favicon.ico"
    );

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        start = System.currentTimeMillis();

        for (String i : STATIC_RESOURCES) {
            if (request.getRequestURI().startsWith(i)) {
                return true;
            }
        }

        String userIP = request.getRemoteAddr();

        if (!requestCounts.containsKey(userIP)) {
            beginning = System.currentTimeMillis();
            requestCounts.put(userIP, 0);
        }

        System.out.println(requestCounts);

        if (requestCounts.get(userIP) >= MAX_REQUESTS) {
            if (System.currentTimeMillis() - beginning > 60000) {
                requestCounts.put(userIP, 0);
                beginning = System.currentTimeMillis();
                System.out.println(requestCounts);
            } else {
                response.setStatus(429);
                response.getWriter().write("Rate Limit exceeded. Try Again Later.");
                System.out.println("\nRate Limit exceeded. Try Again Later.\n");
                return false;
            }
        } else {
            requestCounts.put(userIP, requestCounts.get(userIP) + 1);
            System.out.println("\nUser accessed: " + request.getRequestURI() + " ID: " + request.getRequestId());
            System.out.println(userIP + " has been accessed this URI " + requestCounts.get(userIP) + " time(s).\n");
        }

        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        System.out.println(request.getRequestURI() + " Has been processed...Response : " + HttpStatus.valueOf(response.getStatus()));
        System.out.println("Response is being sent...");
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        long executionTime = System.currentTimeMillis() - start;
        System.out.println("\nExecuted in " + executionTime + " milliseconds\n");
    }

}

