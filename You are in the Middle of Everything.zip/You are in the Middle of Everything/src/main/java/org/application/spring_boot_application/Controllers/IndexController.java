package org.application.spring_boot_application.Controllers;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.application.spring_boot_application.DTOs.AlbumPayloadDTO;
import org.application.spring_boot_application.DTOs.AlbumViewDTO;
import org.application.spring_boot_application.DTOs.UserDTO;
import org.application.spring_boot_application.Entities.Album;
import org.application.spring_boot_application.Entities.Post;
import org.application.spring_boot_application.Entities.Role;
import org.application.spring_boot_application.Entities.User;
import org.application.spring_boot_application.Mappers.AlbumMapper;
import org.application.spring_boot_application.Mappers.UserMapper;
import org.application.spring_boot_application.Models.PostModel;
import org.application.spring_boot_application.Models.UserModel;
import org.application.spring_boot_application.Profiles.Profile;
import org.application.spring_boot_application.Services.AlbumService;
import org.application.spring_boot_application.Services.RoleService;
import org.application.spring_boot_application.Services.UserService;
import org.application.spring_boot_application.util.JwtUtil;
import org.application.spring_boot_application.util.constants.accountError;
import org.application.spring_boot_application.util.constants.accountSuccess;
import org.application.spring_boot_application.util.constants.albumError;
import org.application.spring_boot_application.util.constants.roles;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import io.jsonwebtoken.lang.Arrays;
import io.jsonwebtoken.security.InvalidKeyException;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;

import jakarta.servlet.http.HttpServletResponse;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Valid;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;

@RestController
@RequestMapping("/api/v1/index")
@Tag(name = "Index API", description = "This may be what an API is but it is just a big maybe")
public class IndexController {

    private final AlbumService albumService;

    private final JwtUtil jwtUtil;

    private final AuthenticationManager authenticationManager;

    private final UserService userService;

    private final RoleService roleService;

    private final PasswordEncoder passwordEncoder;

    public IndexController(JwtUtil jwtUtil, AuthenticationManager authenticationManager, UserService userService, RoleService roleService, PasswordEncoder passwordEncoder, AlbumService albumService) {
        this.jwtUtil = jwtUtil;
        this.authenticationManager = authenticationManager;
        this.userService = userService;
        this.roleService = roleService;
        this.passwordEncoder = passwordEncoder;
        this.albumService = albumService;
    }

    private static Authentication cachedAuthentication;

    public static Authentication getCachedAuthentication() {
        return cachedAuthentication;
    }

    @PostMapping(value = "/authorize", consumes = "Application/JSON")
    @ResponseStatus(HttpStatus.OK)
    @ApiResponse(responseCode = "200", description = "Please enter the email address and the password of the desired User to be authenticated.")
    @ApiResponse(responseCode = "400", description = "Credentials are invalid or not found.")
    @Operation(summary = "Authenticate a User from the given credentials")
    public ResponseEntity<?> authorize(@RequestBody UserDTO userDTO, HttpServletResponse response) throws InvalidKeyException, NoSuchAlgorithmException, InvalidKeySpecException {

        Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(userDTO.getUsernameString(), userDTO.getPasswordString()));

        String jwt;

        try {
            jwt = jwtUtil.generateToken(userDTO.getUsernameString());
        } catch (InvalidKeyException | NoSuchAlgorithmException | InvalidKeySpecException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(accountError.TOKEN_GENERATION_ERROR.getAccountErrorString() + " " + e);
        }

        return ResponseEntity.ok(Map.of("authentication", authentication, "token", jwt, "username", jwtUtil.extractUsername(jwt)));
    }

    @PostMapping(value = "/addUser", consumes = "Application/JSON")
    @ResponseStatus(HttpStatus.CREATED)
    @ApiResponse(responseCode = "400", description = "Please enter an email and a password. There credentials will be validated.")
    @ApiResponse(responseCode = "201", description = "Email and Password are valid, a new User has been successfully created and stored in the database.")
    @Operation(summary = "Populate the database, add a User")
    @PreAuthorize("hasAuthority('ADD_A_USER')")
    public ResponseEntity<String> addUser(@RequestBody UserDTO userDTO) {
        try {
            userDTO.setUser_id(null);
            User user = new User();
            user.setEmailString(userDTO.getEmailString());
            user.setPasswordString(passwordEncoder.encode(userDTO.getPasswordString()));
            user.setUsernameString(userDTO.getUsernameString());

            ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
            Validator validator = factory.getValidator();

            Set<ConstraintViolation<User>> violations = validator.validate(user);

            if (!violations.isEmpty()) {
                return ResponseEntity.badRequest().body(violations.toString());
            }

            userService.save(user);
            roleService.addRolesToUser(user.getUsernameString(), Set.of(roles.USER.getRoleId()));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(accountError.ADD_ACCOUNT_ERROR.getAccountErrorString() + " " + e);
        }
        return ResponseEntity.status(HttpStatus.CREATED).body(accountSuccess.ACCOUNT_ADDED.getAccountSuccessString());
    }

    @GetMapping(value = "/profile")
    @ApiResponse(responseCode = "200", description = "A Profile of the current Authentication has been created.")
    @ApiResponse(responseCode = "401", description = "JWT Token missing")
    @ApiResponse(responseCode = "403", description = "JWT Token Error")
    @Operation(summary = "Viewing a profile of the current authenticated User")
    @SecurityRequirement(name = "Index API")
    public ResponseEntity<Profile> profile() {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        User user = userService.getUserByUsernameString(username);
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_XML).body(UserMapper.toProfile(user));
    }

    @PreAuthorize("hasRole('SUPER_ADMIN')")
    @PostMapping("/resetPassword")
    @ResponseStatus(HttpStatus.OK)
    @ApiResponse(responseCode = "200", description = "User Password has been updated.")
    @ApiResponse(responseCode = "400", description = "User not Found")
    @Operation(summary = "Reset the password of the given User")
    public ResponseEntity<String> resetPassword(@RequestBody UserDTO userDTO) {
        try {
            userService.updateUserPassword(userDTO.getUser_id(), userDTO.getPasswordString());
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.valueOf(400)).body("User not Found");
        }
        return ResponseEntity.ok().body("User password successfully updated");
    }

    @GetMapping("/delete/{id}")
    @PreAuthorize("hasAuthority('DELETE_ANY_USER')")
    @ResponseStatus(HttpStatus.OK)
    @ApiResponse(responseCode = "200", description = "User has been deleted.")
    @ApiResponse(responseCode = "400", description = "User not Found")
    @Operation(summary = "Delete the given User")
    public ResponseEntity<String> deleteUser(@PathVariable Long id) {
        try {
            userService.deleteUserById(id);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok("User successfully deleted");
    }

    @PostMapping("/add_role")
    @PreAuthorize("hasAnyRole('ADMIN', 'SUPER_ADMIN')")
    @ResponseStatus(HttpStatus.OK)
    @ApiResponse(responseCode = "200", description = "New User role has been added.")
    @ApiResponse(responseCode = "400", description = "Unexsistan User or Role")
    @Operation(summary = "Add roles to the User")
    public ResponseEntity<String> addRole(@RequestParam Long userId, @RequestParam String role) {
        try {
            User user = userService.getUserById(userId);
            Role roleTemp = roleService.getByRoleNameString(role);
            roleService.addRolesToUser(user.getUsernameString(), Set.of(roleTemp.getRoleId()));
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok("Role added to the User");
    }

    @PreAuthorize("hasAnyRole('ADMIN', 'SUPER_ADMIN')")
    @PostMapping(value = "/ban_or_unban_user", consumes = "Application/JSON")
    @ResponseStatus(HttpStatus.OK)
    @ApiResponse(responseCode = "200", description = "Ban the current user from the given userId.")
    @ApiResponse(responseCode = "400", description = "UserId not found.")
    public ResponseEntity<String> banOrUnbanUser(@RequestParam("userId") Long userId) {
        User user = userService.getUserById(userId);
        for (Role role : user.getRoles()) {
            if ("BANNED".equals(role.getRoleNameString())) {
                roleService.removeRoleFromUser(user.getUsernameString(), roles.BANNED.getRoleId());
                roleService.addRolesToUser(user.getUsernameString(), Set.of(roles.USER.getRoleId()));
                return ResponseEntity.ok("The user has been unbanned, it is functional again as a USER account");
            } else {
                for (Role roleTemp : user.getRoles()) {
                    roleService.removeRoleFromUser(user.getUsernameString(), roleTemp.getRoleId());
                }
                roleService.addRolesToUser(user.getUsernameString(), Set.of(roles.BANNED.getRoleId()));
                return ResponseEntity.ok("The user has been banned and his roles are taken");
            }
        }
        return null;
    }

    @PostMapping(value = "/addAlbum", consumes = "Application/JSON")
    @ResponseStatus(HttpStatus.CREATED)
    @ApiResponse(responseCode = "201", description = "Album successfully created")
    @ApiResponse(responseCode = "400", description = "Something went wrong.")
    @Operation(summary = "An Album should be added to the database")
    @SecurityRequirement(name = "Index API")
    public ResponseEntity<?> addAlbum(@Valid @RequestBody AlbumPayloadDTO albumPayloadDTO) {
        try {
            String username = SecurityContextHolder.getContext().getAuthentication().getName();
            User user = userService.getUserByUsernameString(username);
            Album album = new Album(null, albumPayloadDTO.getAlbumTitleString(), albumPayloadDTO.getDescriptionString(), null, new ArrayList<>(), new ArrayList<>(), user);
            albumService.save(album);
            user.addAlbum(album);
            AlbumViewDTO albumViewDTO = new AlbumViewDTO(album.getAlbumId(), album.getAlbumTitleString(), album.getDescriptionString());
            return ResponseEntity.status(HttpStatus.CREATED).body(albumViewDTO);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(albumError.ALBUM_ERROR.getAlbumErrorString() + " " + e);
        }
    }

    
    @PostMapping(value = "/uploadPhoto", consumes = {"multipart/form-data"})
    @ResponseStatus(HttpStatus.OK)
    @ApiResponse(responseCode = "200", description = "Photo successfully added to the Album")
    @ApiResponse(responseCode = "400", description = "Something went wrong.")
    @Operation(summary = "A Photo should be uploaded to the Album")
    @SecurityRequirement(name = "Index API")
    public ResponseEntity<?> addAlbum(@RequestParam Long albumId, @RequestPart(required = true) MultipartFile[] multipartfiles) throws IOException {

        List<MultipartFile> files = new ArrayList<>();
        Arrays.asList(multipartfiles).stream().forEach(multipartfile -> {
            files.add(multipartfile);
        });

        if (files.isEmpty()) {
            return ResponseEntity.badRequest().body("No File selected");
        }

        Path uploadDir = Paths.get(System.getProperty("user.dir"), "photos");

        if (!Files.exists(uploadDir)) {
            Files.createDirectories(uploadDir);
        }

        Album album = albumService.getAlbumbyId(albumId);

        for (MultipartFile i : multipartfiles) {
            Path saveFile;
            switch (i.getContentType()) {
                case "image/jpeg":
                    saveFile = uploadDir.resolve(UUID.randomUUID().toString() + ".jpg");
                    i.transferTo(saveFile.toFile());
                    album.getPhotos().add(saveFile.toString());
                    break;
                case "image/png":
                    saveFile = uploadDir.resolve(UUID.randomUUID().toString() + ".png");
                    i.transferTo(saveFile.toFile());
                    album.getPhotos().add(saveFile.toString());
                    break;
                default:
                    return ResponseEntity.badRequest().body("Unsupported file format, only png and jpg are welcome");
            }
        }

        return ResponseEntity.ok("All Files has been Uploaded");
    }

    @GetMapping("meta/json/albums")
    public ResponseEntity<List<AlbumViewDTO>> getAlbumsJson(@RequestParam Long userId) {
        List<AlbumViewDTO> albumViewDTOs = new ArrayList<>();
        for (Album i : albumService.getAllAlbumsFromUser(userId)) {
            albumViewDTOs.add(AlbumMapper.toAlbumViewDTO(i));
        }
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(albumViewDTOs);
    }

    @GetMapping("meta/xml/albums")
    public ResponseEntity<List<AlbumViewDTO>> getAlbumsXml(@RequestParam Long userId) {
        List<AlbumViewDTO> albumViewDTOs = new ArrayList<>();
        for (Album i : albumService.getAllAlbumsFromUser(userId)) {
            albumViewDTOs.add(AlbumMapper.toAlbumViewDTO(i));
        }
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_XML).body(albumViewDTOs);
    }
    
    @GetMapping("/jwt")
    public ResponseEntity<?> jwt() throws InvalidKeyException, NoSuchAlgorithmException, InvalidKeySpecException {
        String jwt = jwtUtil.generateToken(SecurityContextHolder.getContext().getAuthentication().getName());
        return ResponseEntity.ok(Map.of("token", jwt, "username", jwtUtil.extractUsername(jwt)));
    }

    @GetMapping("meta/xml/users")
    public ResponseEntity<?> getUsersXml(@RequestParam(required = false) String format) {
        Collection<User> users = UserModel.getUserModel().getUserList().values();

        if ("xml".equalsIgnoreCase(format)) {
            return ResponseEntity.ok().contentType(MediaType.APPLICATION_XML).body(users);
        }
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(users);
    }

    @GetMapping("meta/xml/user")
    public ResponseEntity<User> findUserByIdXml(@RequestParam Long id) throws RuntimeException {
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_XML).body(UserModel.getUser(id));
    }

    @GetMapping("meta/json/users")
    public ResponseEntity<?> getUsersJson(@RequestParam(required = false) String format) {
        Map<Long, User> users = UserModel.getUserModel().getUserList();

        if ("xml".equalsIgnoreCase(format)) {
            return ResponseEntity.ok().contentType(MediaType.APPLICATION_XML).body(users);
        }
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(users);
    }

    @GetMapping("meta/json/user/")
    public ResponseEntity<User> findUserByIdJson(@RequestParam Long id) throws RuntimeException {
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(UserModel.getUser(id));
    }

    @GetMapping("meta/xml/posts")
    public ResponseEntity<?> getPostsXml(@RequestParam(required = false) String format) {
        Collection<Post> posts = PostModel.getPostModel().getPostList().values();

        if ("xml".equalsIgnoreCase(format)) {
            return ResponseEntity.ok().contentType(MediaType.APPLICATION_XML).body(posts);
        }
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(posts);
    }

    @GetMapping("meta/xml/post")
    public ResponseEntity<Post> findPostByIdXml(@RequestParam Long id) throws RuntimeException {
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_XML).body(PostModel.getPost(id));
    }

    @GetMapping("meta/json/posts")
    public ResponseEntity<?> getPostsJson(@RequestParam(required = false) String format) {
        Map<Long, Post> posts = PostModel.getPostModel().getPostList();

        if ("xml".equalsIgnoreCase(format)) {
            return ResponseEntity.ok().contentType(MediaType.APPLICATION_XML).body(posts);
        }
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(posts);
    }

    @GetMapping("meta/json/post")
    public ResponseEntity<Post> findPostByIdJson(@RequestParam Long id) throws RuntimeException {
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(PostModel.getPost(id));
    }

}
