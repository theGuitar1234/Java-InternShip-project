package org.application.spring_boot_application.Services;

import java.util.Optional;

import org.application.spring_boot_application.Entities.Authority;
import org.application.spring_boot_application.Repositories.AuthorityRepository;
import org.springframework.stereotype.Service;

@Service
public class AuthorityService {

    private final AuthorityRepository authorityRepository;

    public AuthorityService(AuthorityRepository authorityRepository) {
        this.authorityRepository = authorityRepository;
    }

    public Authority save(Authority authority) {
        Authority savedAuthority = authorityRepository.save(authority);
        return savedAuthority;
    }

    public Authority getByAuthorityId(Long id) {
        Optional<Authority> authorityOptional = authorityRepository.findByAuthorityId(id);
        Authority authority = authorityOptional.orElseThrow(() -> new RuntimeException("Authority not Found"));
        return authority;
    }
}
