package org.application.spring_boot_application.SeedData;

import java.util.Set;

import org.application.spring_boot_application.Entities.Authority;
import org.application.spring_boot_application.Entities.Post;
import org.application.spring_boot_application.Entities.Role;
import org.application.spring_boot_application.Entities.User;

import org.application.spring_boot_application.Services.AuthorityService;
import org.application.spring_boot_application.Services.CustomUserDetailsService;
import org.application.spring_boot_application.Services.PostService;
import org.application.spring_boot_application.Services.RoleService;
import org.application.spring_boot_application.Services.UserService;

import org.application.spring_boot_application.util.constants.authorities;
import org.application.spring_boot_application.util.constants.roles;

import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class SeedData implements CommandLineRunner {
    
    private final PostService postService;

    private final UserService userService;

    private final AuthorityService authorityService;
    
    private final RoleService roleService;

    private final CustomUserDetailsService userDetailsService;

    private final PasswordEncoder passwordEncoder;

    public SeedData(PostService postService, UserService userService, AuthorityService authorityService, RoleService roleService, CustomUserDetailsService userDetailsService, PasswordEncoder passwordEncoder) {
        this.postService = postService;
        this.userService = userService;
        this.authorityService = authorityService;
        this.roleService = roleService;
        this.userDetailsService = userDetailsService;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) throws Exception {

        for (authorities auth : authorities.values()) {
            Authority authority = new Authority();

            authority.setAuthorityId(auth.getAuthorityId());
            authority.setAuthorityNameString(auth.getAuthorityString());

            authorityService.save(authority);
        }

        for (roles role : roles.values()) {
            Role roleTemp = new Role();

            roleTemp.setRoleId(role.getRoleId());
            roleTemp.setRoleNameString(role.getRoleString());

            Set<Long> authorityIds;

            switch (roleTemp.getRoleNameString()) {
                case "SUPER_ADMIN":
                    authorityIds = Set.of(authorities.RESET_ANY_USER_PASSWORD.getAuthorityId(),
                                                    authorities.ADD_A_USER.getAuthorityId(),
                                                    authorities.ACCESS_ADMIN_PANEL.getAuthorityId(),  
                                                    authorities.DELETE_ANY_USER.getAuthorityId(),
                                                    authorities.SET_ANY_ROLE.getAuthorityId());
                    break;
                case "ADMIN":
                    authorityIds = Set.of(authorities.ACCESS_ADMIN_PANEL.getAuthorityId(),
                                                    authorities.ADD_A_USER.getAuthorityId(),  
                                                    authorities.DELETE_ANY_USER.getAuthorityId(),
                                                    authorities.SET_ANY_ROLE.getAuthorityId());
                    break;
                case "USER":
                    authorityIds = Set.of(authorities.READ_ANY_CONTENT.getAuthorityId());
                    break;
                case "EDITOR":
                    authorityIds = Set.of(authorities.WRITE_ANY_CONTENT.getAuthorityId(),
                                                    authorities.UPDATE_ANY_CONTENT.getAuthorityId());
                    break;
                case "BANNED":
                    authorityIds = Set.of(authorities.NO_AUTHORITIES.getAuthorityId());
                    break;
                case "MANAGER":
                    authorityIds = Set.of(authorities.ACCESS_ADMIN_PANEL.getAuthorityId());
                    break;
                case "MODERATOR":
                    authorityIds = Set.of(authorities.DELETE_ANY_CONTENT.getAuthorityId(),
                                                    authorities.WRITE_ANY_CONTENT.getAuthorityId(),
                                                    authorities.UPDATE_ANY_CONTENT.getAuthorityId());
                    break;
                case "GUEST":
                    authorityIds = Set.of(authorities.READ_ANY_CONTENT.getAuthorityId());
                    break;
                default:
                    throw new RuntimeException("Invalid roleString");
            }

            for (Long authorityId : authorityIds) {
                Authority authority = authorityService.getByAuthorityId(authorityId);

                roleTemp.addAuthority(authority);
                authority.addRole(roleTemp);
            }
    
            roleService.save(roleTemp);
        }

        Post post1 = new Post();
        Post post2 = new Post();
        Post post3 = new Post();

        User user1 = new User();
        User user2 = new User();

        user1.setUsernameString("Guitar_11");
        user1.setFirstnameString("Thomas");
        user1.setSurnameString("William");
        user1.setAge(23);
        user1.setEmailString("tantenontam@gmail.com");
        user1.setPasswordString(passwordEncoder.encode("1234"));
        user1.setPhoneNumberString("+9940507213235");
        user1.setGenderString("Male");
        
        user2.setUsernameString("Guitar_12");
        user2.setFirstnameString("Lucia");
        user2.setSurnameString("Watterson");
        user2.setAge(23);
        user2.setEmailString("tantenontam1@gmail.com");
        user2.setPasswordString(passwordEncoder.encode("1234"));
        user2.setPhoneNumberString("+9940507213234");
        user2.setGenderString("Female");

        post1.setPostTitleString("Post 01 Title");
        post1.setPostBodyString("Post 01 Body");
        
        post2.setPostTitleString("Post 02 Title");
        post2.setPostBodyString("Post 02 Body");

        post3.setPostTitleString("Post 03 Title");
        post3.setPostBodyString("Post 03 Body");

        //userService.saveAll(user1, user2);
        userService.save(user1);
        userService.save(user2);
        
        roleService.addRolesToUser("Guitar_11", Set.of(roles.USER.getRoleId(), roles.SUPER_ADMIN.getRoleId()));
        roleService.addRolesToUser("Guitar_12", Set.of(roles.BANNED.getRoleId()));

        user1.addPost(post1);
        user1.addPost(post3);
        user2.addPost(post2);

        postService.save(post1);
        postService.save(post2);
        postService.save(post3);

        userDetailsService.loadUserByUsername(user1.getUsernameString());
        userDetailsService.loadUserByUsername(user2.getUsernameString());
        
    }
}

