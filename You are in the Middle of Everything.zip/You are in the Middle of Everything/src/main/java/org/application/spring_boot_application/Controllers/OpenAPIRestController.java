package org.application.spring_boot_application.Controllers;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class OpenAPIRestController {
    
}
