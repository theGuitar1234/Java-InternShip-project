package org.application.spring_boot_application.Models;

import java.util.HashMap;
import java.util.Map;

import org.application.spring_boot_application.Entities.Post;
import org.springframework.stereotype.Component;

@Component
public class PostModel {
    private static PostModel postModel;
    private Map<Long, Post> postList;
    
    public static PostModel getPostModel() {
        if (postModel == null) {
            postModel = new PostModel();
            return postModel;
        } else {
            return postModel;
        }
    }

    public Map<Long, Post> getPostList() {
        if (postList == null) {
            postList = new HashMap<>();
            return postList;
        } else {
            return postList;
        }
    }

    public static void addPost(Post post) {
        if (post != null) {
            PostModel.getPostModel().getPostList().put(post.getPostId(), post);
        }
    }

    public static Post getPost(Long id) {
        return PostModel.getPostModel().getPostList().get(id);
    }

     public static void removePost(Long id) {
        if (PostModel.getPost(id) != null) {
            PostModel.getPostModel().getPostList().remove(id);
        }
    }

    public static void removeAllposts() {
        if (!PostModel.getPostModel().getPostList().isEmpty()) {
            PostModel.getPostModel().getPostList().clear();
        }
    }
}
