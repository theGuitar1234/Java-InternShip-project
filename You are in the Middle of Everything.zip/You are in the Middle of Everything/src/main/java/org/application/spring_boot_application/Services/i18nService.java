package org.application.spring_boot_application.Services;

import org.springframework.stereotype.Service;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;

import jakarta.servlet.http.HttpServletRequest;

import java.io.InputStream;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Map;
import java.util.Properties;

@Service
public class i18nService {

    private static String localeString;

    private static String FILE_PATH;

    public synchronized void updateMessage(Map<String, String> params, HttpServletRequest request) {

        localeString = request.getSession().getAttribute(SessionLocaleResolver.LOCALE_SESSION_ATTRIBUTE_NAME).toString();

        FILE_PATH = "i18n/messages_" + localeString + ".properties";

        try (InputStream input = new FileInputStream(FILE_PATH)) {
            Properties properties = new Properties();
            properties.load(input);
            input.close();

            for (String key : params.keySet()) {
                properties.setProperty(key, params.get(key));
            }

            try (OutputStream output = new FileOutputStream(FILE_PATH)) {
                properties.store(output, "Updated message properties");
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
