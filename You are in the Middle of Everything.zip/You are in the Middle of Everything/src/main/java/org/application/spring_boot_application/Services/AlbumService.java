package org.application.spring_boot_application.Services;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.application.spring_boot_application.Entities.Album;
import org.application.spring_boot_application.Repositories.AlbumRepository;

import org.springframework.stereotype.Service;

@Service
public class AlbumService {

    private final UserService userService;

    private final AlbumRepository albumRepository;

    public AlbumService(AlbumRepository albumRepository, UserService userService) {
        this.albumRepository = albumRepository;
        this.userService = userService;
    }

     public Album save(Album album) {
        if (album.getAdded() == null) {
            album.setAdded(LocalDateTime.now());
        }
        Album savedAlbum = albumRepository.save(album);
        return savedAlbum;
    }

    public Album getAlbumbyId(Long albumId) {
        Optional<Album> albumOptional = albumRepository.findById(albumId);
        Album album = albumOptional.orElseThrow(() -> new RuntimeException("Album not Found"));
        return album;
    }

    public List<Album> getAllAlbumsFromUser(Long userId) {
        return userService.getUserById(userId).getAlbums();
    }
}
