package org.application.spring_boot_application.Controllers;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

import org.application.spring_boot_application.Services.PasswordResetService;
import org.application.spring_boot_application.util.JwtUtil;
import org.application.spring_boot_application.util.constants.authorities;
import org.application.spring_boot_application.util.constants.roles;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
//import org.springframework.security.core.context.SecurityContext;
//import org.springframework.security.core.context.SecurityContextHolder;
//import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.stereotype.Controller;

import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import io.jsonwebtoken.security.InvalidKeyException;
import jakarta.mail.MessagingException;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
@RequestMapping("/restricted")
public class SecurityController {

    private final JwtUtil jwtUtil;

    private final AuthenticationManager authenticationManager;

    private final PasswordResetService passwordResetService;

    public SecurityController(AuthenticationManager authenticationManager, JwtUtil jwtUtil, PasswordResetService passwordResetService) {
        this.authenticationManager = authenticationManager;
        this.jwtUtil = jwtUtil;
        this.passwordResetService = passwordResetService;
    }

    private static Authentication cachedAuthentication;

    public static Authentication getCachedAuthentication() {
        return cachedAuthentication;
    }

    @GetMapping("/")
    public String restricted(HttpServletRequest request, Model model) {
        model.addAttribute("error", request.getParameter("error"));
        return "restricted";
    }

    @GetMapping("/authenticate")
    public String authenticate() {
        return "restricted";
    }

    @GetMapping("/guestAuthenticate")
    public String guestAuthenticate(@RequestParam String guestUsernameTemp, @RequestParam String guestPasswordTemp, Model model) {
        model.addAttribute("guestUsername", guestUsernameTemp);
        model.addAttribute("guestPassword", guestPasswordTemp);
        return "restricted";
    }
    

    @PostMapping("/authenticate")
    public String authenticate(@RequestParam String username, @RequestParam String password, HttpServletRequest request, HttpServletResponse response) throws IOException, AuthenticationException, BadCredentialsException {

        Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));

        if (authentication.getAuthorities().toString().contains(authorities.NO_AUTHORITIES.getAuthorityString()) ||
            authentication.getAuthorities().toString().contains("ROLE_" + roles.BANNED.getRoleString())) {

            response.setStatus(403);
            response.getWriter().write(authentication.getName() + " is banned");
            System.out.println(authentication.getName() + " is banned\n");
            return null;
        }

        System.out.println("\n" + authentication + "\n");

        cachedAuthentication = authentication;

        String jwt;

        try {
            jwt = jwtUtil.generateToken(username);
            Cookie cookie = new Cookie("jwt", jwt);
            cookie.setHttpOnly(true);
            cookie.setSecure(false);
            cookie.setPath("/");
            cookie.setMaxAge((int) (jwtUtil.getExpirationDate()/1000));

            response.addCookie(cookie);
        } catch (InvalidKeyException | NoSuchAlgorithmException | InvalidKeySpecException e) {
            e.printStackTrace();
        }

        //SecurityContext securityContext = SecurityContextHolder.getContext();
        //request.getSession().setAttribute(HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY, securityContext);

        return "redirect:/home/";

    }

    @GetMapping("/forgot_password")
    public String forgotPassword() {
        return "forgot_password";
    }

    @GetMapping("/otpCode")
    public String otpCode() {
        return "otpCode";
    }
    

    @PostMapping("/forgot_password")
    public String forgotPassword(@RequestParam String email, Model model) throws MessagingException {
        passwordResetService.createPasswordResetToken(email);
        model.addAttribute("message", "Password Reset Link sent");
        return "forgot_password";
    }

    @PostMapping("/otpCode")
    public String orpCode(@RequestParam String email, Model model) throws MessagingException {
        passwordResetService.createOtpCode(email);
        model.addAttribute("message", "Otp Code sent");
        model.addAttribute("email", email);
        return "otpCode";
    }

    @PostMapping("/verifyOtp")
    public String verifyOtp(@RequestParam String otpCode, @RequestParam String email, Model model) {
        if (passwordResetService.isOtpValid(email, otpCode)) {
            model.addAttribute("email", email);
            model.addAttribute("otpCode", otpCode);
            return "otp_reset_password";
        } else {
            return "error";
        }
    }
    
    @GetMapping("/token_reset_password")
    public String resetPassword(@RequestParam("token") String token, Model model) {
        if (passwordResetService.isTokenValid(token)) {
            model.addAttribute("token", token);
            return "token_reset_password";
        } else {
            return "error";
        }
    }

    @PostMapping("/token_reset_password")
    public String resetPassword(@RequestParam("token") String token, @RequestParam("password") String password, HttpServletRequest request)  {
        if(passwordResetService.tokenResetPassword(token, password, request)) {
            return "redirect:/restricted/";
        } else {
            return "error";
        }
    }

    @PostMapping("/otp_reset_password")
    public String resetPassword(@RequestParam String email, @RequestParam String otpCode, @RequestParam("password") String password, HttpServletRequest request)  {
        if(passwordResetService.otpResetPassword(email, otpCode, password, request)) {
            return "redirect:/restricted/";
        } else {
            return "error";
        }
    }
    
}

