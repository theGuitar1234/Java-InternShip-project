package org.application.spring_boot_application.Services;

import java.util.Optional;
import java.util.Set;

import org.application.spring_boot_application.Entities.Role;
import org.application.spring_boot_application.Entities.User;
import org.application.spring_boot_application.Models.UserModel;
import org.application.spring_boot_application.Repositories.RoleRepository;
import org.application.spring_boot_application.Repositories.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class RoleService {

    private final RoleRepository roleRepository;

    private final UserRepository userRepository;

    public RoleService(RoleRepository roleRepository, UserRepository userRepository) {
        this.roleRepository = roleRepository;
        this.userRepository = userRepository;
    }

    public Role save(Role role) {
        Role savedRole = roleRepository.save(role);
        return savedRole;
    }

    public Role getByRoleId(Long id) {
        Optional<Role> roleOptional = roleRepository.findByRoleId(id);
        Role role = roleOptional.orElseThrow(() -> new RuntimeException("Role not Found"));
        return role;
    }

    public Role getByRoleNameString(String roleNameString) {
        Optional<Role> roleOptional = roleRepository.findByRoleNameString(roleNameString);
        Role role = roleOptional.orElseThrow(() -> new RuntimeException("Role Not Found"));
        return role;
    }
    
    @Transactional
    public void addRolesToUser(String username, Set<Long> roleIds) {
        Optional<User> userOptional = userRepository.findByUsernameString(username);
        User user = userOptional.orElseThrow(() -> new RuntimeException("User not Found"));

        for (Long roleId : roleIds) {
            Role role = getByRoleId(roleId);
            user.addRole(getByRoleId(roleId));
            role.addUser(user);
            UserModel.addUser(user);
        }
    }

    @Transactional
    public void removeRoleFromUser(String username, Long roleId) {
        Optional<User> userOptional = userRepository.findByUsernameString(username);
        User user = userOptional.orElseThrow(() -> new RuntimeException("User not Found"));
        Role role = getByRoleId(roleId);
        user.removeRole(role);
        role.removeUser(user);
    }
}
