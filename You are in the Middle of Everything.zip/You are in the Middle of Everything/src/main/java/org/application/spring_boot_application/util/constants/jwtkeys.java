package org.application.spring_boot_application.util.constants;

public enum jwtkeys {
    JWT_PRIVATE_KEY("ME4CAQAwEAYHKoZIzj0CAQYFK4EEACIENzA1AgEBBDBevzrE4EzXksE6eSQNwB0uhZMtq9O6BInyMoe32rynT9STdqp/u+2mpC5LGVnkNe4="),
    JWT_PUBLIC_KEY("MHYwEAYHKoZIzj0CAQYFK4EEACIDYgAEwNADbKNgiU93bARTzmy/PWaGGh8iL9xPIRLA8IYhPO7Nr4d+y/B6HR0ce8gXZgqoB43fL9aOvp8eFMYEX+PMBtTXtzjFWTEuc8CugHqFFmEPmfLziOH7q0QRxtxvWZ/Y");

    private final String jwtKeyString;

    private jwtkeys(String jwtKeyString) {
        this.jwtKeyString = jwtKeyString;
    }

    public String getJwtKeyString() {
        return this.jwtKeyString;
    }
}

