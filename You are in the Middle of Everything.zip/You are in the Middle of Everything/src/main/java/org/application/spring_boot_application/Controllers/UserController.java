package org.application.spring_boot_application.Controllers;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.Principal;
import java.time.LocalDateTime;
import java.util.Set;
import java.util.UUID;

import org.application.spring_boot_application.DTOs.UserDTO;
import org.application.spring_boot_application.Entities.User;
import org.application.spring_boot_application.Mappers.UserMapper;
import org.application.spring_boot_application.Repositories.UserRepository;
import org.application.spring_boot_application.Services.RoleService;
import org.application.spring_boot_application.Services.UserService;
import org.application.spring_boot_application.util.constants.roles;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;

import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;

@Controller
@RequestMapping("/user")
public class UserController {

    private final UserService userService;

    private final RoleService roleService;

    private final PasswordEncoder passwordEncoder;

    private final UserRepository userRepository;

    public UserController(UserService userService, RoleService roleService, PasswordEncoder passwordEncoder, UserRepository userRepository) {
        this.userService = userService;
        this.roleService = roleService;
        this.passwordEncoder = passwordEncoder;
        this.userRepository = userRepository;
    }

    @GetMapping("/login")
    public String login(Model model) {
        model.addAttribute("user", new User());
        return "login";
    }

    @PostMapping("/login")
    public String login(@ModelAttribute User user, Model model) throws RuntimeException {
        UserDTO userDTO = UserMapper.toUserDTO(user);

        if (userService.authenticateUser(userDTO) != null) {
            User userAuth = userService.authenticateUser(userDTO);

            model.addAttribute("user", userAuth);
            model.addAttribute("roles", userAuth.getRoles());

            return "member";
        } else {
            throw new RuntimeException();
        }
    } 

    @GetMapping("/member")
    public String member() {
        return "member";
    }

    @GetMapping("/guest")
    public String guest(HttpServletResponse response) {
        User user = new User();
        
        user.setUsernameString("Guest_" + UUID.randomUUID().toString());
        user.setCreatedAt(LocalDateTime.now());
        user.setPasswordString(passwordEncoder.encode("guest_user_password_not_needed"));

        userRepository.save(user);
        roleService.addRolesToUser(user.getUsernameString(), Set.of(roles.GUEST.getRoleId()));

        return "redirect:/restricted/guestAuthenticate?guestUsernameTemp=" + user.getUsernameString() + "&guestPasswordTemp=guest_user_password_not_needed";
    }

    @GetMapping("/logout")
    public String logout(Principal principal, HttpServletRequest request) {

        String username = principal.getName();
        User user = userService.getUserByUsernameString(username);
        userService.deleteUserById(user.getUserId());
        SecurityContextHolder.clearContext();
        request.getSession().invalidate();

        return "redirect:/restricted/";
    }

    @GetMapping("/edit_profile/{userId}")
    public String editProfile(@PathVariable("userId") long userId, Model model) {
        model.addAttribute("user", userService.getUserById(userId));
        model.addAttribute("userId", userId);
        return "edit_profile";
    }

    @PostMapping("/edit_profile/{userId}")
    public String editProfile(@ModelAttribute @Valid User user, @PathVariable("userId") long userId, BindingResult bindingResult, Model model) {
        if (bindingResult.hasErrors()) {
            bindingResult.getAllErrors().forEach(error -> 
                System.out.println("Validation error: " + error.getDefaultMessage() + "\n")
            );
            model.addAttribute("user", user);
            return "edit_profile";
        }

        User userTemp = userService.getUserById(userId);
        userTemp.setAge(user.getAge());
        userTemp.setDateOfBirth(user.getDateOfBirth());
        userTemp.setEmailString(user.getEmailString());
        userTemp.setFirstnameString(user.getFirstnameString());
        userTemp.setGenderString(user.getGenderString());
        userTemp.setPasswordString(passwordEncoder.encode(user.getPasswordString()));
        userTemp.setPhoneNumberString(user.getPhoneNumberString());
        userTemp.setSurnameString(user.getSurnameString());

        userService.save(userTemp);

        return "redirect:/user/login";
    }

    @PostMapping("/update_profile_picture/{userId}")
    public String updateProfilePicture(@PathVariable("userId") Long userId, @RequestParam("file") MultipartFile file) throws IllegalStateException, IOException {
        
        if (file.isEmpty()) {
            throw new RuntimeException("File not Found");
        }

        Path uploadDir = Paths.get(System.getProperty("user.dir"), "uploads");

        if (!Files.exists(uploadDir)) {
            Files.createDirectories(uploadDir);
        }

        Path destination = uploadDir.resolve(UUID.randomUUID().toString());
        
        File saveFile = new File(destination.toString());
        file.transferTo(saveFile);
        
        User userTemp = userService.getUserById(userId);
        
        if (!"/sprites/profile_picture.jpg".equals(userTemp.getProfilePhotoPath())) {
            Files.delete(Paths.get(userTemp.getProfilePhotoPath()));    
        }

        userTemp.setProfilePhotoPath("/uploads/" + saveFile.getName());
        System.out.println(userTemp.getProfilePhotoPath());
        
        userService.save(userTemp);
        
        return "redirect:/user/login";
    }
    
}
