package org.application.spring_boot_application.Mappers;

import org.application.spring_boot_application.DTOs.AlbumPayloadDTO;
import org.application.spring_boot_application.DTOs.AlbumViewDTO;
import org.application.spring_boot_application.Entities.Album;

import org.springframework.stereotype.Component;

@Component
public class AlbumMapper {

    public static AlbumPayloadDTO toAlbumPayloadDTO(Album album) {
        if (album != null) {
            return new AlbumPayloadDTO(album.getAlbumTitleString(), album.getDescriptionString());
        }
        return null;
    }

    public static AlbumViewDTO toAlbumViewDTO(Album album) {
        if (album != null) {
            return new AlbumViewDTO(album.getAlbumId() , album.getAlbumTitleString(), album.getDescriptionString());
        }
        return null;
    }

}
