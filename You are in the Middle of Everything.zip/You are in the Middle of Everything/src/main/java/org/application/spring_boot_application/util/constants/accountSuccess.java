package org.application.spring_boot_application.util.constants;

public enum accountSuccess {
    ACCOUNT_ADDED("ACCOUNT_ADDED");

    private String accountSuccessString;

    private accountSuccess(String accountSuccessString) {
        this.accountSuccessString = accountSuccessString;
    }

    public String getAccountSuccessString() {
        return this.accountSuccessString;
    }
}
