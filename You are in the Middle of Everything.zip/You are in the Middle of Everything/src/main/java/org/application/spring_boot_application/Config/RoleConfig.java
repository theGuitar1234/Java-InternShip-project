// package org.application.spring_boot_application.Config;

// import org.springframework.context.annotation.Bean;
// import org.springframework.context.annotation.Configuration;
// import org.springframework.security.access.hierarchicalroles.RoleHierarchy;
// import org.springframework.security.access.hierarchicalroles.RoleHierarchyImpl;

// @Configuration
// public class RoleConfig {

//     @Bean
//     RoleHierarchy roleHierarchy() {
//        RoleHierarchyImpl roleHierarchy = new RoleHierarchyImpl();
//        roleHierarchy.setHierarchy("""
//             ROLE_SUPER_ADMIN > ROLE_ADMIN
//             ROLE_ADMIN > ROLE_MANAGER
//             ROLE_MANAGER > ROLE_MODERATOR
//             ROLE_MODERATOR > ROLE_EDITOR
//             ROLE_EDITOR > ROLE_USER
//             ROLE_USER > ROLE_GUEST
//             ROLE_GUEST > ROLE_BANNED        
//          """);
//         return roleHierarchy;
//     }
    
// }
