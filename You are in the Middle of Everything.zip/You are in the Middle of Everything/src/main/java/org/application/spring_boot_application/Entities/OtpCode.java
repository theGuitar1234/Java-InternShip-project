package org.application.spring_boot_application.Entities;

import java.time.Instant;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "otp_codes")
@Getter
@Setter
@NoArgsConstructor
public class OtpCode {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long otpId;
    
    @Column(name = "otp_code", nullable = false, length = 6)
    private String otpCode;

    @Column(name = "email", nullable = false)
    private String email;

    @Column(name = "expiration_date", nullable = false) 
    private Instant expirationDate;

    @OneToOne
    @JoinColumn(name = "user_id")
    private User user;

}
